const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { loginLimiter } = require('../middleware/rateLimiter');

// Database pool injected from server.js
module.exports = (pool) => {

  // POST /api/auth/register
  router.post('/register', async (req, res) => {
    const { phoneNumber, password, displayName } = req.body;

    if (!phoneNumber || !password || !displayName) {
      return res.status(400).json({
        success: false,
        message: 'Phone number, password, and display name are required.',
        errorCode: 'MISSING_FIELDS'
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters long.',
        errorCode: 'WEAK_PASSWORD'
      });
    }

    try {
      // Check phone uniqueness
      const existingUser = await pool.query('SELECT id FROM users WHERE phone_number = $1', [phoneNumber]);
      if (existingUser.rows.length > 0) {
        return res.status(409).json({
          success: false,
          message: 'An account with this phone number already exists.',
          errorCode: 'PHONE_EXISTS'
        });
      }

      // Hash password
      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);

      // Insert User
      const newUser = await pool.query(
        'INSERT INTO users (phone_number, password_hash, display_name) VALUES ($1, $2, $3) RETURNING id, phone_number, display_name, created_at',
        [phoneNumber, passwordHash, displayName]
      );

      const user = newUser.rows[0];

      // Audit Log
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [user.id, 'REGISTER', `Registered account for ${phoneNumber}`]
      );

      // JWT Token
      const token = jwt.sign(
        { userId: user.id, phoneNumber: user.phone_number },
        process.env.JWT_SECRET || 'fallback_jwt_secret',
        { expiresIn: '30d' }
      );

      return res.status(201).json({
        success: true,
        message: 'Account created successfully.',
        data: {
          userId: user.id,
          token: token,
          displayName: user.display_name,
          phoneNumber: user.phone_number
        }
      });
    } catch (err) {
      console.error('Register error:', err);
      return res.status(500).json({ success: false, message: 'Server error during registration.' });
    }
  });

  // POST /api/auth/login
  router.post('/login', loginLimiter, async (req, res) => {
    const { phoneNumber, password } = req.body;

    if (!phoneNumber || !password) {
      return res.status(400).json({
        success: false,
        message: 'Phone number and password are required.',
        errorCode: 'MISSING_FIELDS'
      });
    }

    try {
      const userRes = await pool.query('SELECT * FROM users WHERE phone_number = $1', [phoneNumber]);
      if (userRes.rows.length === 0) {
        return res.status(401).json({
          success: false,
          message: 'Invalid phone number or password.',
          errorCode: 'INVALID_CREDENTIALS'
        });
      }

      const user = userRes.rows[0];
      const isMatch = await bcrypt.compare(password, user.password_hash);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid phone number or password.',
          errorCode: 'INVALID_CREDENTIALS'
        });
      }

      // Audit Log
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [user.id, 'LOGIN', 'User logged in successfully']
      );

      const token = jwt.sign(
        { userId: user.id, phoneNumber: user.phone_number },
        process.env.JWT_SECRET || 'fallback_jwt_secret',
        { expiresIn: '30d' }
      );

      return res.json({
        success: true,
        message: `Welcome back, ${user.display_name}!`,
        data: {
          userId: user.id,
          token: token,
          displayName: user.display_name,
          phoneNumber: user.phone_number
        }
      });
    } catch (err) {
      console.error('Login error:', err);
      return res.status(500).json({ success: false, message: 'Server error during login.' });
    }
  });

  return router;
};
