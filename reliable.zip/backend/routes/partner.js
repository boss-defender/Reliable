const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');

function generateAlphanumericCode(length = 6) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

module.exports = (pool) => {

  // POST /api/partner/code/generate
  router.post('/code/generate', authenticateToken, async (req, res) => {
    const userId = req.user.userId;

    try {
      const userRes = await pool.query('SELECT current_status, partner_id FROM users WHERE id = $1', [userId]);
      if (userRes.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'User not found.' });
      }

      const user = userRes.rows[0];
      if (user.current_status === 'Linked' || user.partner_id) {
        return res.status(400).json({
          success: false,
          message: 'You already have an active partner link inside Reliable. Unlink first before generating new invitation codes.',
          errorCode: 'ALREADY_LINKED'
        });
      }

      // Expire existing active codes for user
      await pool.query(
        "UPDATE partner_invites SET status = 'expired' WHERE creator_user_id = $1 AND status = 'active'",
        [userId]
      );

      const code = generateAlphanumericCode(6);
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      const inviteRes = await pool.query(
        'INSERT INTO partner_invites (code, creator_user_id, expires_at) VALUES ($1, $2, $3) RETURNING code, expires_at',
        [code, userId, expiresAt]
      );

      // Update status to Pending invitation
      await pool.query("UPDATE users SET current_status = 'Pending invitation' WHERE id = $1", [userId]);

      // Audit Log
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [userId, 'GENERATE_CODE', `Generated invite code ${code}`]
      );

      return res.json({
        success: true,
        message: 'Partner invitation code generated successfully.',
        data: {
          code: inviteRes.rows[0].code,
          expiresAt: new Date(inviteRes.rows[0].expires_at).getTime()
        }
      });
    } catch (err) {
      console.error('Generate code error:', err);
      return res.status(500).json({ success: false, message: 'Server error generating code.' });
    }
  });

  // POST /api/partner/code/verify
  router.post('/code/verify', authenticateToken, async (req, res) => {
    const joiningUserId = req.user.userId;
    const { code } = req.body;

    if (!code || code.trim().length !== 6) {
      return res.status(400).json({
        success: false,
        message: 'A valid 6-character code is required.',
        errorCode: 'INVALID_CODE_FORMAT'
      });
    }

    const cleanCode = code.trim().toUpperCase();

    try {
      const joiningRes = await pool.query('SELECT * FROM users WHERE id = $1', [joiningUserId]);
      const joiningUser = joiningRes.rows[0];

      if (joiningUser.current_status === 'Linked' || joiningUser.partner_id) {
        return res.status(400).json({
          success: false,
          message: 'Your account already has an active partner link inside Reliable.',
          errorCode: 'ALREADY_LINKED'
        });
      }

      // Check invite
      const inviteRes = await pool.query('SELECT * FROM partner_invites WHERE code = $1', [cleanCode]);
      if (inviteRes.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'Invalid or non-existent partner invitation code.',
          errorCode: 'CODE_NOT_FOUND'
        });
      }

      const invite = inviteRes.rows[0];

      if (invite.status === 'used') {
        return res.status(400).json({
          success: false,
          message: 'This invitation code has already been used.',
          errorCode: 'CODE_ALREADY_USED'
        });
      }

      if (new Date(invite.expires_at) <= new Date() || invite.status === 'expired') {
        return res.status(400).json({
          success: false,
          message: 'This invitation code has expired. Ask your partner to generate a new code.',
          errorCode: 'CODE_EXPIRED'
        });
      }

      if (invite.creator_user_id === joiningUserId) {
        return res.status(400).json({
          success: false,
          message: 'You cannot enter your own invitation code.',
          errorCode: 'SELF_LINK_FORBIDDEN'
        });
      }

      const creatorRes = await pool.query('SELECT * FROM users WHERE id = $1', [invite.creator_user_id]);
      const creatorUser = creatorRes.rows[0];

      if (creatorUser.current_status === 'Linked' || creatorUser.partner_id) {
        return res.status(400).json({
          success: false,
          message: 'The account that created this code is already linked to another partner.',
          errorCode: 'PARTNER_ALREADY_LINKED'
        });
      }

      // Perform Linking in transaction
      await pool.query('BEGIN');

      // Create link
      await pool.query(
        "INSERT INTO partner_links (user1_id, user2_id, status) VALUES ($1, $2, 'Linked')",
        [creatorUser.id, joiningUserId]
      );

      // Mark invite used
      await pool.query("UPDATE partner_invites SET status = 'used' WHERE id = $1", [invite.id]);

      // Update both user records
      await pool.query(
        "UPDATE users SET current_status = 'Linked', partner_id = $1 WHERE id = $2",
        [joiningUserId, creatorUser.id]
      );
      await pool.query(
        "UPDATE users SET current_status = 'Linked', partner_id = $1 WHERE id = $2",
        [creatorUser.id, joiningUserId]
      );

      // Audit logs
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [joiningUserId, 'LINK_PARTNER', `Linked with partner ${creatorUser.display_name} (${creatorUser.phone_number})`]
      );
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [creatorUser.id, 'LINK_PARTNER', `Partner ${joiningUser.display_name} joined via code ${cleanCode}`]
      );

      await pool.query('COMMIT');

      return res.json({
        success: true,
        message: `Successfully linked with ${creatorUser.display_name}!`,
        data: {
          partnerName: creatorUser.display_name,
          partnerPhone: creatorUser.phone_number
        }
      });

    } catch (err) {
      await pool.query('ROLLBACK');
      console.error('Verify code error:', err);
      return res.status(500).json({ success: false, message: 'Server error linking partner.' });
    }
  });

  // POST /api/partner/unlink
  router.post('/unlink', authenticateToken, async (req, res) => {
    const userId = req.user.userId;

    try {
      const userRes = await pool.query('SELECT partner_id, display_name FROM users WHERE id = $1', [userId]);
      const user = userRes.rows[0];
      const partnerId = user.partner_id;

      await pool.query('BEGIN');

      // Update partner links
      await pool.query(
        "UPDATE partner_links SET status = 'Unlinked' WHERE (user1_id = $1 OR user2_id = $1) AND status = 'Linked'",
        [userId]
      );

      // Reset user status
      await pool.query("UPDATE users SET current_status = 'Unlinked', partner_id = NULL WHERE id = $1", [userId]);

      // Reset partner status if exists
      if (partnerId) {
        await pool.query("UPDATE users SET current_status = 'Unlinked', partner_id = NULL WHERE id = $1", [partnerId]);
        await pool.query(
          'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
          [partnerId, 'UNLINK_PARTNER', `Unlinked by partner ${user.display_name}`]
        );
      }

      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [userId, 'UNLINK_PARTNER', 'User initiated partner unlinking']
      );

      await pool.query('COMMIT');

      return res.json({ success: true, message: 'Partner unlinked successfully.' });

    } catch (err) {
      await pool.query('ROLLBACK');
      console.error('Unlink error:', err);
      return res.status(500).json({ success: false, message: 'Server error unlinking partner.' });
    }
  });

  return router;
};
