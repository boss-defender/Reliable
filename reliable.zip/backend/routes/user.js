const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const authenticateToken = require('../middleware/auth');

module.exports = (pool) => {

  // GET /api/user/me
  router.get('/me', authenticateToken, async (req, res) => {
    try {
      const userRes = await pool.query(
        'SELECT id, phone_number, display_name, created_at, is_verified, current_status, partner_id FROM users WHERE id = $1',
        [req.user.userId]
      );

      if (userRes.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'User profile not found.' });
      }

      const user = userRes.rows[0];
      let partnerInfo = null;

      if (user.partner_id) {
        const partnerRes = await pool.query(
          'SELECT id, display_name, phone_number FROM users WHERE id = $1',
          [user.partner_id]
        );
        if (partnerRes.rows.length > 0) {
          const p = partnerRes.rows[0];
          partnerInfo = {
            id: p.id,
            displayName: p.display_name,
            phoneNumber: p.phone_number
          };
        }
      }

      return res.json({
        success: true,
        data: {
          id: user.id,
          phoneNumber: user.phone_number,
          displayName: user.display_name,
          createdAt: new Date(user.created_at).getTime(),
          isVerified: user.is_verified,
          relationshipStatus: user.current_status,
          partner: partnerInfo
        }
      });
    } catch (err) {
      console.error('Get user profile error:', err);
      return res.status(500).json({ success: false, message: 'Server error retrieving user.' });
    }
  });

  // POST /api/user/report
  router.post('/report', authenticateToken, async (req, res) => {
    const { reportedUserId, reason, details } = req.body;

    try {
      await pool.query(
        'INSERT INTO reports (reporter_user_id, reported_user_id, reason, details) VALUES ($1, $2, $3, $4)',
        [req.user.userId, reportedUserId || req.user.userId, reason || 'General Report', details || '']
      );

      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [req.user.userId, 'REPORT', `Submitted report for ${reason}`]
      );

      return res.json({ success: true, message: 'Report submitted successfully. Moderation team notified.' });
    } catch (err) {
      console.error('Report user error:', err);
      return res.status(500).json({ success: false, message: 'Server error submitting report.' });
    }
  });

  // POST /api/user/block
  router.post('/block', authenticateToken, async (req, res) => {
    const { blockedUserId } = req.body;

    try {
      await pool.query(
        'INSERT INTO blocks (blocker_user_id, blocked_user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [req.user.userId, blockedUserId]
      );

      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [req.user.userId, 'BLOCK', `Blocked user ${blockedUserId}`]
      );

      return res.json({ success: true, message: 'User blocked successfully.' });
    } catch (err) {
      console.error('Block user error:', err);
      return res.status(500).json({ success: false, message: 'Server error blocking user.' });
    }
  });

  // POST /api/user/change-password
  router.post('/change-password', authenticateToken, async (req, res) => {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword || newPassword.length < 8) {
      return res.status(400).json({ success: false, message: 'Valid current password and new password (8+ chars) required.' });
    }

    try {
      const userRes = await pool.query('SELECT password_hash FROM users WHERE id = $1', [req.user.userId]);
      const user = userRes.rows[0];

      const isMatch = await bcrypt.compare(currentPassword, user.password_hash);
      if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
      }

      const salt = await bcrypt.genSalt(10);
      const newHash = await bcrypt.hash(newPassword, salt);

      await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, req.user.userId]);
      await pool.query(
        'INSERT INTO audit_logs (user_id, action, details) VALUES ($1, $2, $3)',
        [req.user.userId, 'CHANGE_PASSWORD', 'Password changed successfully']
      );

      return res.json({ success: true, message: 'Password updated successfully.' });
    } catch (err) {
      console.error('Change password error:', err);
      return res.status(500).json({ success: false, message: 'Server error updating password.' });
    }
  });

  // DELETE /api/user/account
  router.delete('/account', authenticateToken, async (req, res) => {
    try {
      await pool.query('DELETE FROM users WHERE id = $1', [req.user.userId]);
      return res.json({ success: true, message: 'Account permanently deleted.' });
    } catch (err) {
      console.error('Delete account error:', err);
      return res.status(500).json({ success: false, message: 'Server error deleting account.' });
    }
  });

  return router;
};
