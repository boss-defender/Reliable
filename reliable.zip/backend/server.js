require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const { apiLimiter } = require('./middleware/rateLimiter');

const app = express();
const PORT = process.env.PORT || 5000;

// PostgreSQL Database Pool setup
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

pool.connect((err, client, release) => {
  if (err) {
    console.error('Error connecting to PostgreSQL database:', err.stack);
  } else {
    console.log('Connected to PostgreSQL Database successfully.');
    release();
  }
});

// Global Middleware
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());
app.use('/api/', apiLimiter);

// Health Check Endpoint
app.get('/', (req, res) => {
  res.json({
    status: 'ONLINE',
    app: 'Reliable Relationship Trust Backend Engine',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Import API Routes
const authRoutes = require('./routes/auth')(pool);
const partnerRoutes = require('./routes/partner')(pool);
const userRoutes = require('./routes/user')(pool);

app.use('/api/auth', authRoutes);
app.use('/api/partner', partnerRoutes);
app.use('/api/user', userRoutes);

// 404 Route Handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Endpoint not found.' });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Global Error Handler:', err);
  res.status(500).json({ success: false, message: 'Internal Server Error' });
});

app.listen(PORT, () => {
  console.log(`Reliable Express Server running on port ${PORT}`);
});
