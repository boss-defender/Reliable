# Reliable Backend Service (Node.js + Express + PostgreSQL)

Production-ready backend API service for **Reliable** — relationship trust verification platform.

## Architecture

* **Runtime**: Node.js (>=18)
* **Framework**: Express.js
* **Database**: PostgreSQL
* **Security**: bcryptjs password hashing, JWT authentication, Express Rate Limiter, CORS protection
* **Deployment**: Render Web Service + Render PostgreSQL

---

## Database Setup

1. Provision a PostgreSQL Database (e.g. on Render PostgreSQL or local PostgreSQL).
2. Execute the database initialization script located at `/backend/database/schema.sql`:

```bash
psql $DATABASE_URL -f database/schema.sql
```

This creates the tables:
- `users`
- `sessions`
- `partner_invites`
- `partner_links`
- `reports`
- `blocks`
- `audit_logs`

---

## Environment Variables

Configure the following environment variables in your Render environment configuration:

| Variable | Description | Example |
| :--- | :--- | :--- |
| `PORT` | Web server port | `5000` |
| `NODE_ENV` | Environment mode | `production` |
| `DATABASE_URL` | PostgreSQL connection URI | `postgres://user:pass@ep-host.render.com/reliable_db` |
| `JWT_SECRET` | Secret key for signing JWT tokens | `super_secret_key_change_in_production` |
| `CORS_ORIGIN` | Allowed CORS origins | `*` |

---

## Deploying to Render

### Option A: Render Dashboard
1. Log in to [Render Dashboard](https://dashboard.render.com).
2. Click **New +** -> **PostgreSQL**. Name it `reliable-db`. Copy the **Internal Database URL** or **External Connection String**.
3. Click **New +** -> **Web Service**. Connect your GitHub repository containing this project.
4. Set Root Directory to `backend` (or build context).
5. Build Command: `npm install`
6. Start Command: `node server.js`
7. Add Environment Variables:
   - `DATABASE_URL` = `<your_render_postgres_connection_string>`
   - `JWT_SECRET` = `<your_random_secret_string>`
   - `NODE_ENV` = `production`
8. Click **Create Web Service**. Your API will be live at `https://reliable-backend.onrender.com`.

---

## REST API Endpoints Summary

### Authentication
- `POST /api/auth/register` — Create account with phone, password & display name.
- `POST /api/auth/login` — Sign in with rate-limited login checks.

### User Profile & Settings
- `GET /api/user/me` — Fetch current user profile & partner link details.
- `POST /api/user/change-password` — Update account security credentials.
- `DELETE /api/user/account` — Permanently delete user account and wipe partner links.

### Partner Linking Engine
- `POST /api/partner/code/generate` — Generate 6-character partner invitation code (10-min expiry).
- `POST /api/partner/code/verify` — Verify invitation code and link accounts.
- `POST /api/partner/unlink` — Unlink partner accounts and update statuses to Unlinked.

### Safety & Moderation
- `POST /api/user/report` — Submit confidential abuse or impersonation report.
- `POST /api/user/block` — Block user and auto-terminate active partner link.

---

## Running Locally

```bash
cd backend
npm install
cp .env.example .env
# Update .env with your local PostgreSQL URI
npm run dev
```
