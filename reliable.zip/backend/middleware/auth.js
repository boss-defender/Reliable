const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication token required.',
      errorCode: 'UNAUTHORIZED'
    });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'fallback_jwt_secret', (err, user) => {
    if (err) {
      return res.status(403).json({
        success: false,
        message: 'Invalid or expired token.',
        errorCode: 'FORBIDDEN'
      });
    }
    req.user = user;
    next();
  });
};

module.exports = authenticateToken;
