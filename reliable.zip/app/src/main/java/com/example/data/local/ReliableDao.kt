package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReliableDao {
    // User Queries
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun getUserByIdFlow(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getUserByPhone(phoneNumber: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUser(userId: String)

    // Partner Invite Queries
    @Query("SELECT * FROM partner_invites WHERE code = :code LIMIT 1")
    suspend fun getInviteByCode(code: String): PartnerInviteEntity?

    @Query("SELECT * FROM partner_invites WHERE creatorUserId = :userId AND status = 'active' ORDER BY createdAt DESC LIMIT 1")
    fun getActiveInviteForUserFlow(userId: String): Flow<PartnerInviteEntity?>

    @Query("SELECT * FROM partner_invites WHERE creatorUserId = :userId AND status = 'active' ORDER BY createdAt DESC LIMIT 1")
    suspend fun getActiveInviteForUser(userId: String): PartnerInviteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvite(invite: PartnerInviteEntity)

    @Update
    suspend fun updateInvite(invite: PartnerInviteEntity)

    @Query("UPDATE partner_invites SET status = 'expired' WHERE expiresAt < :currentTime AND status = 'active'")
    suspend fun expireOldInvites(currentTime: Long)

    // Partner Link Queries
    @Query("SELECT * FROM partner_links WHERE (user1Id = :userId OR user2Id = :userId) AND status = 'Linked' LIMIT 1")
    suspend fun getActiveLinkForUser(userId: String): PartnerLinkEntity?

    @Query("SELECT * FROM partner_links WHERE (user1Id = :userId OR user2Id = :userId) AND status = 'Linked' LIMIT 1")
    fun getActiveLinkForUserFlow(userId: String): Flow<PartnerLinkEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPartnerLink(link: PartnerLinkEntity)

    @Query("UPDATE partner_links SET status = 'Unlinked' WHERE id = :linkId")
    suspend fun unlinkPartner(linkId: String)

    // Reports & Blocks
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlock(block: BlockEntity)

    @Query("SELECT * FROM blocks WHERE blockerUserId = :userId ORDER BY createdAt DESC")
    fun getBlockedUsersFlow(userId: String): Flow<List<BlockEntity>>

    @Query("DELETE FROM blocks WHERE blockerUserId = :userId AND blockedUserId = :blockedUserId")
    suspend fun unblockUser(userId: String, blockedUserId: String)

    // Audit Logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Query("SELECT * FROM audit_logs WHERE userId = :userId ORDER BY timestamp DESC LIMIT 50")
    fun getAuditLogsFlow(userId: String): Flow<List<AuditLogEntity>>
}
