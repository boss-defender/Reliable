package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val phoneNumber: String,
    val passwordHash: String,
    val displayName: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isVerified: Boolean = true, // Verified inside Reliable platform
    val currentStatus: String = "Unlinked", // Unlinked, Pending invitation, Linked, Paused, Blocked
    val partnerId: String? = null,
    val partnerDisplayName: String? = null,
    val partnerPhone: String? = null,
    val isBlocked: Boolean = false,
    val unlinkRequestedBy: String? = null
)

@Entity(tableName = "partner_invites")
data class PartnerInviteEntity(
    @PrimaryKey val id: String,
    val code: String,
    val creatorUserId: String,
    val creatorDisplayName: String,
    val creatorPhone: String,
    val status: String = "active", // active, used, expired, cancelled
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (10 * 60 * 1000) // 10 minutes default
)

@Entity(tableName = "partner_links")
data class PartnerLinkEntity(
    @PrimaryKey val id: String,
    val user1Id: String,
    val user2Id: String,
    val linkedAt: Long = System.currentTimeMillis(),
    val status: String = "Linked" // Linked, Paused, Unlinked
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val reporterUserId: String,
    val reportedUserId: String,
    val reportedName: String,
    val reason: String,
    val details: String,
    val status: String = "Pending",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "blocks")
data class BlockEntity(
    @PrimaryKey val id: String,
    val blockerUserId: String,
    val blockedUserId: String,
    val blockedName: String,
    val blockedPhone: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val action: String, // REGISTER, LOGIN, GENERATE_CODE, VERIFY_CODE, LINK_PARTNER, UNLINK_PARTNER, REPORT, BLOCK, CHANGE_PASSWORD, DELETE_ACCOUNT
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
