package com.example.data.remote

import retrofit2.Response
import retrofit2.http.*

data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T? = null,
    val errorCode: String? = null
)

data class RegisterRequest(
    val phoneNumber: String,
    val password: String,
    val displayName: String
)

data class LoginRequest(
    val phoneNumber: String,
    val password: String
)

data class AuthData(
    val userId: String,
    val token: String,
    val displayName: String,
    val phoneNumber: String
)

data class PartnerCodeResponse(
    val code: String,
    val expiresAt: Long
)

data class VerifyCodeRequest(
    val code: String
)

data class UserProfileData(
    val id: String,
    val phoneNumber: String,
    val displayName: String,
    val createdAt: Long,
    val isVerified: Boolean,
    val relationshipStatus: String,
    val partner: PartnerInfo?
)

data class PartnerInfo(
    val id: String,
    val displayName: String,
    val phoneNumber: String,
    val linkedAt: Long
)

data class ReportRequest(
    val reportedUserId: String,
    val reason: String,
    val details: String
)

data class BlockRequest(
    val blockedUserId: String
)

data class ChangePasswordRequest(
    val currentPassword: String,
    val newPassword: String
)

interface ReliableApiService {

    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<ApiResponse<AuthData>>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<ApiResponse<AuthData>>

    @GET("api/user/me")
    suspend fun getCurrentUser(@Header("Authorization") token: String): Response<ApiResponse<UserProfileData>>

    @POST("api/partner/code/generate")
    suspend fun generatePartnerCode(@Header("Authorization") token: String): Response<ApiResponse<PartnerCodeResponse>>

    @POST("api/partner/code/verify")
    suspend fun verifyAndLinkPartner(
        @Header("Authorization") token: String,
        @Body request: VerifyCodeRequest
    ): Response<ApiResponse<UserProfileData>>

    @POST("api/partner/unlink")
    suspend fun unlinkPartner(@Header("Authorization") token: String): Response<ApiResponse<Unit>>

    @POST("api/user/report")
    suspend fun reportUser(
        @Header("Authorization") token: String,
        @Body request: ReportRequest
    ): Response<ApiResponse<Unit>>

    @POST("api/user/block")
    suspend fun blockUser(
        @Header("Authorization") token: String,
        @Body request: BlockRequest
    ): Response<ApiResponse<Unit>>

    @POST("api/user/change-password")
    suspend fun changePassword(
        @Header("Authorization") token: String,
        @Body request: ChangePasswordRequest
    ): Response<ApiResponse<Unit>>

    @DELETE("api/user/account")
    suspend fun deleteAccount(@Header("Authorization") token: String): Response<ApiResponse<Unit>>
}
