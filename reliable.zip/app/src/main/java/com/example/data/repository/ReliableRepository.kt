package com.example.data.repository

import com.example.data.local.*
import com.example.util.SecurityUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

sealed class Resource<out T> {
    data class Success<out T>(val data: T, val message: String = "") : Resource<T>()
    data class Error(val message: String, val errorCode: String? = null) : Resource<Nothing>()
    object Loading : Resource<Nothing>()
}

class ReliableRepository(private val dao: ReliableDao) {

    // Simple in-memory rate limiting tracker (login attempts per phone number)
    private val loginAttempts = mutableMapOf<String, Pair<Int, Long>>()

    suspend fun register(phone: String, password: String, confirmPass: String, displayName: String): Resource<UserEntity> =
        withContext(Dispatchers.IO) {
            val sanitizedPhone = SecurityUtils.sanitizePhoneNumber(phone)
            if (sanitizedPhone.length < 8) {
                return@withContext Resource.Error("Please enter a valid phone number with country code.")
            }
            if (password != confirmPass) {
                return@withContext Resource.Error("Passwords do not match.")
            }
            val passErr = SecurityUtils.validatePasswordStrength(password)
            if (passErr != null) {
                return@withContext Resource.Error(passErr)
            }
            if (displayName.trim().isEmpty()) {
                return@withContext Resource.Error("Display name cannot be empty.")
            }

            // Check phone uniqueness
            val existing = dao.getUserByPhone(sanitizedPhone)
            if (existing != null) {
                return@withContext Resource.Error("An account with this phone number already exists.")
            }

            val userId = SecurityUtils.generateUUID()
            val passwordHash = SecurityUtils.hashPassword(password)
            val newUser = UserEntity(
                id = userId,
                phoneNumber = sanitizedPhone,
                passwordHash = passwordHash,
                displayName = displayName.trim(),
                createdAt = System.currentTimeMillis(),
                isVerified = true,
                currentStatus = "Unlinked"
            )

            dao.insertUser(newUser)
            dao.insertAuditLog(
                AuditLogEntity(
                    userId = userId,
                    action = "REGISTER",
                    details = "Registered account for $sanitizedPhone"
                )
            )

            Resource.Success(newUser, "Account created successfully.")
        }

    suspend fun login(phone: String, password: String): Resource<UserEntity> =
        withContext(Dispatchers.IO) {
            val sanitizedPhone = SecurityUtils.sanitizePhoneNumber(phone)
            val now = System.currentTimeMillis()

            // Rate limiting check: max 5 failed attempts per 5 minutes
            val attemptData = loginAttempts[sanitizedPhone]
            if (attemptData != null) {
                val (count, timestamp) = attemptData
                if (count >= 5 && (now - timestamp) < 5 * 60 * 1000) {
                    val remainingSecs = ((5 * 60 * 1000 - (now - timestamp)) / 1000)
                    return@withContext Resource.Error("Too many failed login attempts. Please try again in ${remainingSecs}s.")
                } else if ((now - timestamp) >= 5 * 60 * 1000) {
                    loginAttempts.remove(sanitizedPhone)
                }
            }

            val user = dao.getUserByPhone(sanitizedPhone)
            if (user == null || !SecurityUtils.verifyPassword(password, user.passwordHash)) {
                val currentCount = (attemptData?.first ?: 0) + 1
                loginAttempts[sanitizedPhone] = Pair(currentCount, now)
                return@withContext Resource.Error("Invalid phone number or password.")
            }

            // Successful login -> clear failed attempts
            loginAttempts.remove(sanitizedPhone)

            dao.insertAuditLog(
                AuditLogEntity(
                    userId = user.id,
                    action = "LOGIN",
                    details = "Logged in from mobile client"
                )
            )

            Resource.Success(user, "Welcome back, ${user.displayName}!")
        }

    fun getUserFlow(userId: String): Flow<UserEntity?> = dao.getUserByIdFlow(userId)

    suspend fun getUser(userId: String): UserEntity? = dao.getUserById(userId)

    fun getActiveInviteFlow(userId: String): Flow<PartnerInviteEntity?> =
        dao.getActiveInviteForUserFlow(userId)

    suspend fun generatePartnerInviteCode(userId: String): Resource<PartnerInviteEntity> =
        withContext(Dispatchers.IO) {
            val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")
            if (user.currentStatus == "Linked" || user.partnerId != null) {
                return@withContext Resource.Error("You already have an active partner link inside Reliable. Unlink first to issue new invitations.")
            }

            val now = System.currentTimeMillis()
            dao.expireOldInvites(now)

            // Generate unique 6-character code
            val code = SecurityUtils.generateInviteCode(6)
            val invite = PartnerInviteEntity(
                id = SecurityUtils.generateUUID(),
                code = code,
                creatorUserId = user.id,
                creatorDisplayName = user.displayName,
                creatorPhone = user.phoneNumber,
                status = "active",
                createdAt = now,
                expiresAt = now + (10 * 60 * 1000) // 10 minutes
            )

            dao.insertInvite(invite)

            // Update user status to Pending invitation
            val updatedUser = user.copy(currentStatus = "Pending invitation")
            dao.updateUser(updatedUser)

            dao.insertAuditLog(
                AuditLogEntity(
                    userId = userId,
                    action = "GENERATE_CODE",
                    details = "Generated invite code $code (expires in 10 mins)"
                )
            )

            Resource.Success(invite, "Invite code generated: $code")
        }

    suspend fun verifyAndLinkPartnerCode(joiningUserId: String, rawCode: String): Resource<UserEntity> =
        withContext(Dispatchers.IO) {
            val code = rawCode.trim().uppercase()
            if (code.length != 6) {
                return@withContext Resource.Error("Please enter a valid 6-character invitation code.")
            }

            val joiningUser = dao.getUserById(joiningUserId)
                ?: return@withContext Resource.Error("User session invalid.")

            if (joiningUser.currentStatus == "Linked" || joiningUser.partnerId != null) {
                return@withContext Resource.Error("Your account already has an active partner link inside Reliable.")
            }

            val now = System.currentTimeMillis()
            dao.expireOldInvites(now)

            val invite = dao.getInviteByCode(code)
                ?: return@withContext Resource.Error("Invalid or non-existent partner invitation code.")

            if (invite.status == "expired" || invite.expiresAt <= now) {
                return@withContext Resource.Error("This invitation code has expired. Please ask your partner to generate a new code.")
            }

            if (invite.status == "used") {
                return@withContext Resource.Error("This invitation code has already been used.")
            }

            if (invite.creatorUserId == joiningUserId) {
                return@withContext Resource.Error("You cannot enter your own invitation code.")
            }

            val creatorUser = dao.getUserById(invite.creatorUserId)
                ?: return@withContext Resource.Error("Invitation creator account no longer exists.")

            if (creatorUser.currentStatus == "Linked" || creatorUser.partnerId != null) {
                return@withContext Resource.Error("The partner who created this code is already linked to another account inside Reliable.")
            }

            // Create partner link
            val linkId = SecurityUtils.generateUUID()
            val partnerLink = PartnerLinkEntity(
                id = linkId,
                user1Id = creatorUser.id,
                user2Id = joiningUser.id,
                linkedAt = now,
                status = "Linked"
            )

            dao.insertPartnerLink(partnerLink)

            // Mark invite used
            dao.updateInvite(invite.copy(status = "used"))

            // Update Creator User
            val updatedCreator = creatorUser.copy(
                currentStatus = "Linked",
                partnerId = joiningUser.id,
                partnerDisplayName = joiningUser.displayName,
                partnerPhone = joiningUser.phoneNumber
            )
            dao.updateUser(updatedCreator)

            // Update Joining User
            val updatedJoining = joiningUser.copy(
                currentStatus = "Linked",
                partnerId = creatorUser.id,
                partnerDisplayName = creatorUser.displayName,
                partnerPhone = creatorUser.phoneNumber
            )
            dao.updateUser(updatedJoining)

            dao.insertAuditLog(
                AuditLogEntity(
                    userId = joiningUserId,
                    action = "LINK_PARTNER",
                    details = "Successfully linked partner ${creatorUser.displayName} (${creatorUser.phoneNumber})"
                )
            )
            dao.insertAuditLog(
                AuditLogEntity(
                    userId = creatorUser.id,
                    action = "LINK_PARTNER",
                    details = "Partner ${joiningUser.displayName} joined via invite code $code"
                )
            )

            Resource.Success(updatedJoining, "Successfully linked with ${creatorUser.displayName}!")
        }

    suspend fun refreshUserData(userId: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User session invalid.")
        val now = System.currentTimeMillis()
        dao.expireOldInvites(now)
        Resource.Success(Unit, "Data refreshed.")
    }

    suspend fun requestUnlinkPartner(userId: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")

        // If user is pending invitation, cancel invitation directly
        if (user.currentStatus == "Pending invitation" || user.partnerId == null) {
            val now = System.currentTimeMillis()
            dao.expireOldInvites(now)
            val updatedUser = user.copy(currentStatus = "Unlinked", partnerId = null, partnerDisplayName = null, partnerPhone = null, unlinkRequestedBy = null)
            dao.updateUser(updatedUser)
            dao.insertAuditLog(AuditLogEntity(userId = userId, action = "CANCEL_INVITATION", details = "Cancelled pending partner invitation code"))
            return@withContext Resource.Success(Unit, "Invitation cancelled.")
        }

        val partnerId = user.partnerId ?: return@withContext Resource.Error("No active partner link found.")
        val partner = dao.getUserById(partnerId)

        // Set status to Unlink Requested on both user accounts
        val updatedUser = user.copy(currentStatus = "Unlink Requested", unlinkRequestedBy = userId)
        dao.updateUser(updatedUser)

        if (partner != null) {
            val updatedPartner = partner.copy(currentStatus = "Unlink Requested", unlinkRequestedBy = userId)
            dao.updateUser(updatedPartner)
            dao.insertAuditLog(
                AuditLogEntity(
                    userId = partnerId,
                    action = "UNLINK_REQUESTED",
                    details = "Partner ${user.displayName} requested to end relationship. Mutual confirmation required."
                )
            )
        }

        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "UNLINK_REQUESTED",
                details = "Initiated relationship unlink request. Awaiting partner confirmation."
            )
        )

        Resource.Success(Unit, "Unlink request sent. Partner confirmation required.")
    }

    suspend fun confirmUnlinkPartner(userId: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")
        val partnerId = user.partnerId

        val activeLink = dao.getActiveLinkForUser(userId)
        if (activeLink != null) {
            dao.unlinkPartner(activeLink.id)
        }

        // Reset user status
        val resetUser = user.copy(
            currentStatus = "Unlinked",
            partnerId = null,
            partnerDisplayName = null,
            partnerPhone = null,
            unlinkRequestedBy = null
        )
        dao.updateUser(resetUser)

        // Reset partner status if exists
        if (partnerId != null) {
            val partner = dao.getUserById(partnerId)
            if (partner != null) {
                val resetPartner = partner.copy(
                    currentStatus = "Unlinked",
                    partnerId = null,
                    partnerDisplayName = null,
                    partnerPhone = null,
                    unlinkRequestedBy = null
                )
                dao.updateUser(resetPartner)
                dao.insertAuditLog(
                    AuditLogEntity(
                        userId = partnerId,
                        action = "UNLINK_PARTNER",
                        details = "Relationship unlinked after mutual confirmation with ${user.displayName}"
                    )
                )
            }
        }

        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "UNLINK_PARTNER",
                details = "User confirmed partner unlinking"
            )
        )

        Resource.Success(Unit, "Partner link removed after mutual confirmation.")
    }

    suspend fun cancelUnlinkRequest(userId: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")
        val partnerId = user.partnerId

        val updatedUser = user.copy(currentStatus = "Linked", unlinkRequestedBy = null)
        dao.updateUser(updatedUser)

        if (partnerId != null) {
            val partner = dao.getUserById(partnerId)
            if (partner != null) {
                val updatedPartner = partner.copy(currentStatus = "Linked", unlinkRequestedBy = null)
                dao.updateUser(updatedPartner)
            }
        }

        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "CANCEL_UNLINK_REQUEST",
                details = "Cancelled relationship unlink request"
            )
        )

        Resource.Success(Unit, "Unlink request cancelled. Relationship remains active.")
    }

    suspend fun unlinkPartner(userId: String): Resource<Unit> = confirmUnlinkPartner(userId)

    suspend fun reportUser(reporterUserId: String, reportedUserId: String, reportedName: String, reason: String, details: String): Resource<Unit> =
        withContext(Dispatchers.IO) {
            val report = ReportEntity(
                id = SecurityUtils.generateUUID(),
                reporterUserId = reporterUserId,
                reportedUserId = reportedUserId,
                reportedName = reportedName,
                reason = reason,
                details = details
            )
            dao.insertReport(report)
            dao.insertAuditLog(
                AuditLogEntity(
                    userId = reporterUserId,
                    action = "REPORT",
                    details = "Reported user $reportedName ($reason)"
                )
            )
            Resource.Success(Unit, "Report submitted successfully. Our team will review it.")
        }

    suspend fun blockUser(blockerUserId: String, blockedUserId: String, blockedName: String, blockedPhone: String): Resource<Unit> =
        withContext(Dispatchers.IO) {
            val block = BlockEntity(
                id = SecurityUtils.generateUUID(),
                blockerUserId = blockerUserId,
                blockedUserId = blockedUserId,
                blockedName = blockedName,
                blockedPhone = blockedPhone
            )
            dao.insertBlock(block)

            // Auto-unlink if blocking current partner
            val blocker = dao.getUserById(blockerUserId)
            if (blocker?.partnerId == blockedUserId) {
                unlinkPartner(blockerUserId)
            }

            dao.insertAuditLog(
                AuditLogEntity(
                    userId = blockerUserId,
                    action = "BLOCK",
                    details = "Blocked user $blockedName ($blockedPhone)"
                )
            )

            Resource.Success(Unit, "User $blockedName has been blocked.")
        }

    fun getBlockedUsersFlow(userId: String): Flow<List<BlockEntity>> = dao.getBlockedUsersFlow(userId)

    suspend fun unblockUser(userId: String, blockedUserId: String): Resource<Unit> = withContext(Dispatchers.IO) {
        dao.unblockUser(userId, blockedUserId)
        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "UNBLOCK",
                details = "Unblocked user $blockedUserId"
            )
        )
        Resource.Success(Unit, "User unblocked.")
    }

    suspend fun changePassword(userId: String, currentPass: String, newPass: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")
        if (!SecurityUtils.verifyPassword(currentPass, user.passwordHash)) {
            return@withContext Resource.Error("Current password is incorrect.")
        }
        val passErr = SecurityUtils.validatePasswordStrength(newPass)
        if (passErr != null) {
            return@withContext Resource.Error(passErr)
        }

        val updated = user.copy(passwordHash = SecurityUtils.hashPassword(newPass))
        dao.updateUser(updated)
        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "CHANGE_PASSWORD",
                details = "User successfully updated password"
            )
        )
        Resource.Success(Unit, "Password updated successfully.")
    }

    suspend fun deleteAccount(userId: String, confirmPassword: String): Resource<Unit> = withContext(Dispatchers.IO) {
        val user = dao.getUserById(userId) ?: return@withContext Resource.Error("User not found.")
        if (!SecurityUtils.verifyPassword(confirmPassword, user.passwordHash)) {
            return@withContext Resource.Error("Password confirmation is incorrect.")
        }

        // Unlink partner first if linked
        if (user.partnerId != null) {
            unlinkPartner(userId)
        }

        dao.deleteUser(userId)
        dao.insertAuditLog(
            AuditLogEntity(
                userId = userId,
                action = "DELETE_ACCOUNT",
                details = "User deleted account permanently"
            )
        )
        Resource.Success(Unit, "Account deleted permanently.")
    }

    fun getAuditLogsFlow(userId: String): Flow<List<AuditLogEntity>> = dao.getAuditLogsFlow(userId)
}
