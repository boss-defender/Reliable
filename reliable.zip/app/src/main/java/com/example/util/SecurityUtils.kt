package com.example.util

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

object SecurityUtils {

    private val random = SecureRandom()
    private const val CODE_ALPHANUM = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // Excluded confusing chars like 0, O, 1, I

    fun hashPassword(password: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(password.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(password: String, hash: String): Boolean {
        return hashPassword(password) == hash
    }

    fun generateInviteCode(length: Int = 6): String {
        val sb = StringBuilder(length)
        for (i in 0 until length) {
            val idx = random.nextInt(CODE_ALPHANUM.length)
            sb.append(CODE_ALPHANUM[idx])
        }
        return sb.toString()
    }

    fun generateUUID(): String {
        return UUID.randomUUID().toString()
    }

    fun validatePasswordStrength(password: String): String? {
        if (password.length < 8) {
            return "Password must be at least 8 characters long."
        }
        if (!password.any { it.isDigit() }) {
            return "Password must contain at least one digit."
        }
        if (!password.any { it.isLetter() }) {
            return "Password must contain at least one letter."
        }
        return null
    }

    fun sanitizePhoneNumber(phone: String): String {
        val digitsAndPlus = phone.filter { it.isDigit() || it == '+' }
        if (!digitsAndPlus.startsWith("+")) {
            return "+$digitsAndPlus"
        }
        return digitsAndPlus
    }
}
