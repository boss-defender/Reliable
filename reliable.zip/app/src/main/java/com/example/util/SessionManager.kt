package com.example.util

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("reliable_session_secure", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_USER_ID = "current_user_id"
        private const val KEY_SESSION_TOKEN = "session_token"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_THEME_DARK = "is_dark_theme"
        private const val KEY_CACHED_STATUS = "cached_relationship_status"
        private const val KEY_CACHED_PARTNER_NAME = "cached_partner_display_name"
    }

    fun saveSession(userId: String, token: String) {
        prefs.edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_SESSION_TOKEN, token)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_USER_ID)
            .remove(KEY_SESSION_TOKEN)
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .remove(KEY_CACHED_STATUS)
            .remove(KEY_CACHED_PARTNER_NAME)
            .apply()
    }

    fun getUserId(): String? = prefs.getString(KEY_USER_ID, null)
    fun getSessionToken(): String? = prefs.getString(KEY_SESSION_TOKEN, null)
    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false) && !getUserId().isNullOrEmpty()

    fun setDarkTheme(isDark: Boolean) {
        prefs.edit().putBoolean(KEY_THEME_DARK, isDark).apply()
    }

    fun isDarkTheme(): Boolean = prefs.getBoolean(KEY_THEME_DARK, true)

    // Stale-while-revalidate local caching helpers
    fun saveCachedRelationshipStatus(status: String, partnerDisplayName: String?) {
        prefs.edit()
            .putString(KEY_CACHED_STATUS, status)
            .putString(KEY_CACHED_PARTNER_NAME, partnerDisplayName ?: "")
            .apply()
    }

    fun getCachedRelationshipStatus(): String = prefs.getString(KEY_CACHED_STATUS, "Unlinked") ?: "Unlinked"
    fun getCachedPartnerDisplayName(): String? = prefs.getString(KEY_CACHED_PARTNER_NAME, null)?.ifEmpty { null }
}

