package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.viewmodel.MainViewModel

@Composable
fun ReliableNavigation(
    viewModel: MainViewModel,
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val activeInvite by viewModel.activeInvite.collectAsStateWithLifecycle()
    val blockedUsers by viewModel.blockedUsers.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val hasConnectionError by viewModel.hasConnectionError.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.errorMessage.collect { err ->
            snackbarHostState.showSnackbar(err)
        }
    }

    val isLoggedIn = viewModel.sessionManager.isLoggedIn()

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = ScreenRoutes.SPLASH
            ) {
                // 1. Splash Screen
                composable(ScreenRoutes.SPLASH) {
                    SplashScreen(
                        isLoggedIn = isLoggedIn,
                        onNavigateNext = { route ->
                            navController.navigate(route) {
                                popUpTo(ScreenRoutes.SPLASH) { inclusive = true }
                            }
                        }
                    )
                }

                // 2. Welcome Screen
                composable(ScreenRoutes.WELCOME) {
                    WelcomeScreen(
                        onNavigateRegister = { navController.navigate(ScreenRoutes.REGISTER) },
                        onNavigateLogin = { navController.navigate(ScreenRoutes.LOGIN) }
                    )
                }

                // 3. Register Screen
                composable(ScreenRoutes.REGISTER) {
                    RegisterScreen(
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onRegisterSubmit = { phone, pass, confirmPass, name ->
                            viewModel.register(phone, pass, confirmPass, name) {
                                navController.navigate(ScreenRoutes.HOME) {
                                    popUpTo(ScreenRoutes.WELCOME) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 4. Login Screen
                composable(ScreenRoutes.LOGIN) {
                    LoginScreen(
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onLoginSubmit = { phone, pass ->
                            viewModel.login(phone, pass) {
                                navController.navigate(ScreenRoutes.HOME) {
                                    popUpTo(ScreenRoutes.WELCOME) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 5. Home Dashboard
                composable(ScreenRoutes.HOME) {
                    HomeScreen(
                        user = user,
                        activeInvite = activeInvite,
                        isRefreshing = isRefreshing,
                        hasConnectionError = hasConnectionError,
                        onRefresh = { viewModel.refreshData() },
                        onRequestUnlink = { viewModel.requestUnlinkPartner() },
                        onConfirmUnlink = { viewModel.confirmUnlinkPartner() },
                        onCancelUnlink = { viewModel.cancelUnlinkRequest() },
                        onNavigate = { route -> navController.navigate(route) }
                    )
                }

                // 6. Partner Link Screen
                composable(ScreenRoutes.PARTNER_LINK) {
                    PartnerLinkScreen(
                        user = user,
                        activeInvite = activeInvite,
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onGenerateCode = { viewModel.generateInviteCode() },
                        onNavigateEnterCode = { navController.navigate(ScreenRoutes.ENTER_CODE) },
                        onNavigateKyc = { navController.navigate(ScreenRoutes.KYC) }
                    )
                }

                // 7. Enter Code Screen
                composable(ScreenRoutes.ENTER_CODE) {
                    EnterCodeScreen(
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onSubmitCode = { code ->
                            viewModel.verifyAndLinkCode(code) {
                                navController.navigate(ScreenRoutes.HOME) {
                                    popUpTo(ScreenRoutes.HOME) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 8. Relationship Status Screen
                composable(ScreenRoutes.STATUS_CHECK) {
                    RelationshipStatusScreen(
                        user = user,
                        auditLogs = auditLogs,
                        isLoading = isLoading,
                        isRefreshing = isRefreshing,
                        hasConnectionError = hasConnectionError,
                        onRefresh = { viewModel.refreshData() },
                        onBack = { navController.popBackStack() },
                        onRequestUnlink = { viewModel.requestUnlinkPartner() },
                        onConfirmUnlink = { viewModel.confirmUnlinkPartner() },
                        onCancelUnlink = { viewModel.cancelUnlinkRequest() },
                        onUnlinkPartner = { viewModel.confirmUnlinkPartner() }
                    )
                }

                // 9. Settings Screen
                composable(ScreenRoutes.SETTINGS) {
                    SettingsScreen(
                        user = user,
                        blockedUsers = blockedUsers,
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onChangePassword = { currentPass, newPass ->
                            viewModel.changePassword(currentPass, newPass) {}
                        },
                        onUnblockUser = { blockedUserId ->
                            viewModel.unblockUser(blockedUserId)
                        },
                        onLogout = {
                            viewModel.logout {
                                navController.navigate(ScreenRoutes.WELCOME) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        },
                        onNavigateDeleteAccount = { navController.navigate(ScreenRoutes.DELETE_ACCOUNT) },
                        onNavigateAuditLog = { navController.navigate(ScreenRoutes.AUDIT_LOG) }
                    )
                }

                // Audit Log Screen
                composable(ScreenRoutes.AUDIT_LOG) {
                    AuditLogScreen(
                        auditLogs = auditLogs,
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() }
                    )
                }

                // 10. Report / Block Screen
                composable(ScreenRoutes.REPORT_BLOCK) {
                    ReportBlockScreen(
                        user = user,
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onSubmitReport = { reportedUserId, reportedName, reason, details ->
                            viewModel.reportUser(reportedUserId, reportedName, reason, details) {
                                navController.popBackStack()
                            }
                        },
                        onSubmitBlock = { blockedUserId, blockedName, blockedPhone ->
                            viewModel.blockUser(blockedUserId, blockedName, blockedPhone) {
                                navController.popBackStack()
                            }
                        }
                    )
                }

                // 11. Delete Account Screen
                composable(ScreenRoutes.DELETE_ACCOUNT) {
                    DeleteAccountScreen(
                        isLoading = isLoading,
                        onBack = { navController.popBackStack() },
                        onConfirmDelete = { confirmPass ->
                            viewModel.deleteAccount(confirmPass) {
                                navController.navigate(ScreenRoutes.WELCOME) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // 12. KYC Verification Screen
                composable(ScreenRoutes.KYC) {
                    KycScreen(
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
