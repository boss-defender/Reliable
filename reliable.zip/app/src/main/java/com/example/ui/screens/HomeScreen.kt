package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PartnerInviteEntity
import com.example.data.local.UserEntity
import com.example.ui.components.HomeDashboardSkeleton
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    user: UserEntity?,
    activeInvite: PartnerInviteEntity?,
    isRefreshing: Boolean = false,
    hasConnectionError: Boolean = false,
    onRefresh: () -> Unit = {},
    onRequestUnlink: () -> Unit = {},
    onConfirmUnlink: () -> Unit = {},
    onCancelUnlink: () -> Unit = {},
    onNavigate: (String) -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val joinedDateStr = user?.createdAt?.let { dateFormat.format(Date(it)) } ?: "Today"
    var showUnlinkRequestDialog by remember { mutableStateOf(false) }

    if (showUnlinkRequestDialog) {
        AlertDialog(
            onDismissRequest = { showUnlinkRequestDialog = false },
            title = { Text("Request to Leave Relationship", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)) },
            text = {
                Text(
                    "To unlink or leave the relationship, both partners must verify and confirm leaving. A confirmation request will be sent to your partner.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnlinkRequestDialog = false
                        onRequestUnlink()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    modifier = Modifier.testTag("confirm_unlink_request_dialog_btn")
                ) {
                    Text("Send Unlink Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnlinkRequestDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = OceanSlate,
            titleContentColor = MaterialTheme.colorScheme.onBackground,
            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Reliable", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = GoldAccent))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("💝", style = MaterialTheme.typography.titleMedium)
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigate("settings") }, modifier = Modifier.testTag("home_settings_btn")) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = GoldAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepNavy)
            )
        },
        containerColor = DeepNavy,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        AnimatedContent(
            targetState = user != null,
            transitionSpec = {
                fadeIn(animationSpec = tween(400)) togetherWith fadeOut(animationSpec = tween(400))
            },
            label = "HomeDashboardStateCrossfade",
            modifier = Modifier.padding(paddingValues)
        ) { hasUser ->
            if (!hasUser || user == null) {
                HomeDashboardSkeleton(modifier = Modifier.fillMaxSize())
            } else {
                PullToRefreshBox(
                    isRefreshing = isRefreshing,
                    onRefresh = onRefresh,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                            .testTag("home_screen"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                    if (hasConnectionError) {
                        ConnectionErrorCard(
                            onRetry = onRefresh,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }

                    // Profile & Status Header Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = OceanSlate),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(SurfaceVariantDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = GoldAccent,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = user.displayName,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = user.phoneNumber,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Account created: $joinedDateStr",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateGray
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(16.dp))

                            // Status Row with Animated Status Chip
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Relationship Status",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                StatusChip(status = user.currentStatus)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Animated Relationship Status Card with smooth transitions
                    AnimatedContent(
                        targetState = user.currentStatus,
                        transitionSpec = {
                            (fadeIn(animationSpec = tween(400)) + slideInVertically { it / 3 })
                                .togetherWith(fadeOut(animationSpec = tween(300)) + slideOutVertically { -it / 3 })
                        },
                        label = "RelationshipStatusCardTransition"
                    ) { currentStatus ->
                        when (currentStatus) {
                            "Unlink Requested" -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, AlertRed.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MidnightCard)
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = AlertRed,
                                                modifier = Modifier.size(32.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Unlink Mutual Verification",
                                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                    color = AlertRed
                                                )
                                                if (user.unlinkRequestedBy == user.id) {
                                                    Text(
                                                        text = "You requested to leave the relationship with ${user.partnerDisplayName ?: "your partner"}. Waiting for their verification and confirmation.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                } else {
                                                    Text(
                                                        text = "${user.partnerDisplayName ?: "Your partner"} has requested to end the relationship link. Both partners must verify and confirm.",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))

                                        if (user.unlinkRequestedBy == user.id) {
                                            OutlinedButton(
                                                onClick = onCancelUnlink,
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Text("Cancel Unlink Request")
                                            }
                                        } else {
                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                Button(
                                                    onClick = onConfirmUnlink,
                                                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Text("Confirm & Leave")
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                OutlinedButton(
                                                    onClick = onCancelUnlink,
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Text("Decline Request")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            "Linked" -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, VerifiedGreen.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MidnightCard)
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(CircleShape)
                                                    .background(VerifiedGreen.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Favorite,
                                                    contentDescription = null,
                                                    tint = VerifiedGreen,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(14.dp))
                                            Column {
                                                Text(
                                                    text = "Active Partner Link 💝",
                                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = VerifiedGreen
                                                )
                                                Text(
                                                    text = user.partnerDisplayName ?: "Partner",
                                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onBackground
                                                )
                                                Text(
                                                    text = user.partnerPhone ?: "",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            "Pending invitation" -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, PendingAmber.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MidnightCard)
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.HourglassTop,
                                                contentDescription = null,
                                                tint = PendingAmber,
                                                modifier = Modifier.size(28.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Active Invitation Pending ⏳",
                                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                    color = PendingAmber
                                                )
                                                Text(
                                                    text = "Invite Code: ${activeInvite?.code ?: "---"}",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = GoldAccent
                                                )
                                            }
                                            TextButton(onClick = onRequestUnlink) {
                                                Text("Cancel Code", color = AlertRed, style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                }
                            }
                            else -> {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MidnightCard)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LinkOff,
                                            contentDescription = null,
                                            tint = SlateGray,
                                            modifier = Modifier.size(32.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Currently Unlinked",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Your account is free. Generate an invite code or enter your partner's code below.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Partner Link Actions",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action Grid
                    Row(modifier = Modifier.fillMaxWidth()) {
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.QrCode,
                            title = "Invite by Code",
                            subtitle = "Generate code",
                            tag = "home_invite_code_btn",
                            onClick = { onNavigate("partner_link") }
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.VpnKey,
                            title = "Enter Code",
                            subtitle = "Join partner",
                            tag = "home_enter_code_btn",
                            onClick = { onNavigate("enter_code") }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.VerifiedUser,
                            title = "Status Check",
                            subtitle = "Trust logs & status",
                            tag = "home_status_btn",
                            onClick = { onNavigate("status_check") }
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Badge,
                            title = "KYC Verify",
                            subtitle = "ID verification",
                            tag = "home_kyc_btn",
                            onClick = { onNavigate("kyc") }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.ReportProblem,
                            title = "Report / Block",
                            subtitle = "Safety tools",
                            tag = "home_report_btn",
                            onClick = { onNavigate("report_block") }
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        HomeActionTile(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.LinkOff,
                            title = "Unlink / Leave",
                            subtitle = "Mutual confirm",
                            tag = "home_unlink_tile_btn",
                            onClick = {
                                if (user.currentStatus == "Linked") {
                                    showUnlinkRequestDialog = true
                                } else {
                                    onNavigate("status_check")
                                }
                            }
                        )
                    }

                    if (user.currentStatus == "Linked" || user.currentStatus == "Unlink Requested") {
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = {
                                if (user.currentStatus == "Linked") {
                                    showUnlinkRequestDialog = true
                                } else {
                                    onNavigate("status_check")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("home_unlink_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(AlertRed))
                        ) {
                            Icon(imageVector = Icons.Default.LinkOff, contentDescription = null, tint = AlertRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (user.currentStatus == "Unlink Requested") "View Unlink Status" else "Unlink / Leave Relationship",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
}

@Composable
fun StatusChip(status: String) {
    val targetBgColor = when (status) {
        "Linked" -> VerifiedGreen.copy(alpha = 0.2f)
        "Pending invitation" -> PendingAmber.copy(alpha = 0.2f)
        "Unlink Requested" -> AlertRed.copy(alpha = 0.2f)
        "Blocked" -> AlertRed.copy(alpha = 0.2f)
        else -> SlateGray.copy(alpha = 0.2f)
    }

    val targetTextColor = when (status) {
        "Linked" -> VerifiedGreen
        "Pending invitation" -> PendingAmber
        "Unlink Requested" -> AlertRed
        "Blocked" -> AlertRed
        else -> SlateGray
    }

    val animatedBgColor by animateColorAsState(targetValue = targetBgColor, animationSpec = tween(400), label = "StatusChipBg")
    val animatedTextColor by animateColorAsState(targetValue = targetTextColor, animationSpec = tween(400), label = "StatusChipText")

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by if (status == "Linked" || status == "Pending invitation") {
        infiniteTransition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseScale"
        )
    } else {
        remember { mutableStateOf(1f) }
    }

    Surface(
        modifier = Modifier.scale(pulseScale),
        shape = RoundedCornerShape(20.dp),
        color = animatedBgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, animatedTextColor.copy(alpha = 0.5f))
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = animatedTextColor)
        )
    }
}

@Composable
fun HomeActionTile(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier
            .height(105.dp)
            .testTag(tag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubtleBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SoftMintContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = PrimaryForestGreen, modifier = Modifier.size(20.dp))
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ConnectionErrorCard(
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AlertRed.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MidnightCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(AlertRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudOff,
                    contentDescription = "Backend service unreachable",
                    tint = AlertRed,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Backend Service Unreachable",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Could not establish a connection to the backend service. Tap retry to attempt reconnecting.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("retry_connection_btn")
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Retry Connection", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
            }
        }
    }
}


