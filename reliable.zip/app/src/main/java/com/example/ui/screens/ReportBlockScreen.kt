package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.UserEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportBlockScreen(
    user: UserEntity?,
    isLoading: Boolean,
    onBack: () -> Unit,
    onSubmitReport: (reportedUserId: String, reportedName: String, reason: String, details: String) -> Unit,
    onSubmitBlock: (blockedUserId: String, blockedName: String, blockedPhone: String) -> Unit
) {
    var targetPhoneInput by remember { mutableStateOf(user?.partnerPhone ?: "") }
    var targetNameInput by remember { mutableStateOf(user?.partnerDisplayName ?: "") }
    var selectedReason by remember { mutableStateOf("Harassment / Abuse") }
    var detailsInput by remember { mutableStateOf("") }
    var isReasonExpanded by remember { mutableStateOf(false) }

    val reasons = listOf(
        "Harassment / Abuse",
        "False Identity / Impersonation",
        "Coercive Behavior",
        "Spam / Fraud",
        "Other"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Report / Block User", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("report_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepNavy)
            )
        },
        containerColor = DeepNavy,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
                .testTag("report_block_screen"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Safety & Moderation",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = GoldAccent
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Submit a confidential safety report or block a user. Blocking automatically ends active partner links.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            // User Display Name Input
            OutlinedTextField(
                value = targetNameInput,
                onValueChange = { targetNameInput = it },
                label = { Text("User / Partner Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("report_name_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = OceanSlate,
                    unfocusedContainerColor = OceanSlate,
                    focusedBorderColor = GoldAccent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // User Phone Input
            OutlinedTextField(
                value = targetPhoneInput,
                onValueChange = { targetPhoneInput = it },
                label = { Text("Phone Number") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("report_phone_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = OceanSlate,
                    unfocusedContainerColor = OceanSlate,
                    focusedBorderColor = GoldAccent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Reason Selector Dropdown
            ExposedDropdownMenuBox(
                expanded = isReasonExpanded,
                onExpandedChange = { isReasonExpanded = !isReasonExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedReason,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Reason for Report") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isReasonExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth().testTag("report_reason_dropdown"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = OceanSlate,
                        unfocusedContainerColor = OceanSlate,
                        focusedBorderColor = GoldAccent,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
                ExposedDropdownMenu(
                    expanded = isReasonExpanded,
                    onDismissRequest = { isReasonExpanded = false },
                    modifier = Modifier.background(OceanSlate)
                ) {
                    reasons.forEach { reason ->
                        DropdownMenuItem(
                            text = { Text(reason, color = MaterialTheme.colorScheme.onBackground) },
                            onClick = {
                                selectedReason = reason
                                isReasonExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Additional Details Input
            OutlinedTextField(
                value = detailsInput,
                onValueChange = { detailsInput = it },
                label = { Text("Additional Details / Incident Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .testTag("report_details_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = OceanSlate,
                    unfocusedContainerColor = OceanSlate,
                    focusedBorderColor = GoldAccent,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Action Buttons
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val targetId = user?.partnerId ?: targetPhoneInput
                        onSubmitReport(targetId, targetNameInput, selectedReason, detailsInput)
                    },
                    enabled = !isLoading && targetNameInput.isNotEmpty(),
                    modifier = Modifier.weight(1f).height(50.dp).testTag("submit_report_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = DeepNavy)
                ) {
                    Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Submit Report", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Button(
                    onClick = {
                        val targetId = user?.partnerId ?: targetPhoneInput
                        onSubmitBlock(targetId, targetNameInput, targetPhoneInput)
                    },
                    enabled = !isLoading && targetNameInput.isNotEmpty(),
                    modifier = Modifier.weight(1f).height(50.dp).testTag("submit_block_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Icon(imageVector = Icons.Default.Block, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Block User", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}
