package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AuditLogEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditLogScreen(
    auditLogs: List<AuditLogEntity>,
    isLoading: Boolean = false,
    onBack: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredLogs = remember(auditLogs, selectedFilter) {
        val sorted = auditLogs.sortedByDescending { it.timestamp }
        when (selectedFilter) {
            "SECURITY" -> sorted.filter { it.action in listOf("CHANGE_PASSWORD", "REGISTER", "LOGIN", "DELETE_ACCOUNT") }
            "RELATIONSHIP" -> sorted.filter { it.action in listOf("LINK_PARTNER", "UNLINK_PARTNER", "GENERATE_CODE", "VERIFY_CODE") }
            else -> sorted
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Account Audit Log", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("audit_log_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepNavy)
            )
        },
        containerColor = DeepNavy,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .testTag("audit_log_screen")
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Info Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = OceanSlate,
                border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Verified System Audit Logs",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldAccent)
                        )
                        Text(
                            text = "Read-only history of sensitive actions fetched from backend audit_logs table.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    label = { Text("All Actions (${auditLogs.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldAccent,
                        selectedLabelColor = DeepNavy
                    )
                )
                FilterChip(
                    selected = selectedFilter == "RELATIONSHIP",
                    onClick = { selectedFilter = "RELATIONSHIP" },
                    label = { Text("Linking / Status") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldAccent,
                        selectedLabelColor = DeepNavy
                    )
                )
                FilterChip(
                    selected = selectedFilter == "SECURITY",
                    onClick = { selectedFilter = "SECURITY" },
                    label = { Text("Security") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldAccent,
                        selectedLabelColor = DeepNavy
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = GoldAccent)
                }
            } else if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = OceanSlate)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = SlateGray, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Audit Records Found", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("No actions match the selected filter category.", style = MaterialTheme.typography.bodySmall, color = SlateGray)
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredLogs, key = { it.id }) { log ->
                        AuditLogItemCard(log = log)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditLogItemCard(log: AuditLogEntity) {
    val dateStr = remember(log.timestamp) {
        val sdf = SimpleDateFormat("MMM dd, yyyy · HH:mm:ss", Locale.getDefault())
        sdf.format(Date(log.timestamp))
    }

    val (icon, color, displayAction) = when (log.action) {
        "LINK_PARTNER" -> Triple(Icons.Default.Favorite, VerifiedGreen, "Partner Linked")
        "UNLINK_PARTNER" -> Triple(Icons.Default.LinkOff, AlertRed, "Partner Unlinked")
        "CHANGE_PASSWORD" -> Triple(Icons.Default.Lock, GoldAccent, "Password Changed")
        "REGISTER" -> Triple(Icons.Default.PersonAdd, PendingAmber, "Account Created")
        "LOGIN" -> Triple(Icons.Default.Key, PendingAmber, "User Sign In")
        "GENERATE_CODE" -> Triple(Icons.Default.QrCode, PendingAmber, "Invite Code Created")
        "VERIFY_CODE" -> Triple(Icons.Default.CheckCircle, VerifiedGreen, "Invite Code Verified")
        "REPORT" -> Triple(Icons.Default.ReportProblem, AlertRed, "User Reported")
        "BLOCK" -> Triple(Icons.Default.Block, AlertRed, "User Blocked")
        "DELETE_ACCOUNT" -> Triple(Icons.Default.DeleteForever, AlertRed, "Account Deleted")
        else -> Triple(Icons.Default.History, SlateGray, log.action)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = OceanSlate)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = displayAction,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = color.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = log.action,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = log.details,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = SlateGray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateGray
                    )
                }
            }
        }
    }
}
