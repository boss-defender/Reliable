package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.BlockEntity
import com.example.data.local.UserEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    user: UserEntity?,
    blockedUsers: List<BlockEntity>,
    isLoading: Boolean,
    onBack: () -> Unit,
    onChangePassword: (currentPass: String, newPass: String) -> Unit,
    onUnblockUser: (blockedUserId: String) -> Unit,
    onLogout: () -> Unit,
    onNavigateDeleteAccount: () -> Unit,
    onNavigateAuditLog: () -> Unit = {}
) {
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var currentPassInput by remember { mutableStateOf("") }
    var newPassInput by remember { mutableStateOf("") }

    if (showChangePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Change Password", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)) },
            text = {
                Column {
                    OutlinedTextField(
                        value = currentPassInput,
                        onValueChange = { currentPassInput = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("change_current_password_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newPassInput,
                        onValueChange = { newPassInput = it },
                        label = { Text("New Password (8+ chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("change_new_password_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onChangePassword(currentPassInput, newPassInput)
                        showChangePasswordDialog = false
                        currentPassInput = ""
                        newPassInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = DeepNavy),
                    modifier = Modifier.testTag("submit_change_password_btn")
                ) {
                    Text("Update Password")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = OceanSlate
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Privacy", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepNavy)
            )
        },
        containerColor = DeepNavy,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .testTag("settings_screen"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Summary
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = OceanSlate)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(DeepNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = user?.displayName ?: "User", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text(text = user?.phoneNumber ?: "", style = MaterialTheme.typography.bodySmall, color = SlateGray)
                        }
                    }
                }
            }

            // Security Section
            item {
                Text(text = "Account Security", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldAccent))
            }

            item {
                Card(
                    onClick = { showChangePasswordDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("change_password_item"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = OceanSlate)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = GoldAccent)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Change Password", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Text(text = "Update your account security credentials", style = MaterialTheme.typography.bodySmall, color = SlateGray)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = SlateGray)
                    }
                }
            }

            item {
                Card(
                    onClick = onNavigateAuditLog,
                    modifier = Modifier.fillMaxWidth().testTag("audit_log_item"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = OceanSlate)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = GoldAccent)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Audit Log History", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Text(text = "Read-only record of linking, unlinking & security actions", style = MaterialTheme.typography.bodySmall, color = SlateGray)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = SlateGray)
                    }
                }
            }

            // Privacy Policy & Rules Section
            item {
                Text(text = "Privacy & Rules", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldAccent))
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = OceanSlate)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Policy, contentDescription = null, tint = GoldAccent)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "Privacy Guarantee", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Reliable stores passwords using SHA-256 salted hashes and enforces single partner linking rules. No sensitive chat logs or personal location tracking data is collected.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Support & Contact Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = OceanSlate)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, tint = GoldAccent)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "Support & Contact", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Need assistance or wish to report platform abuse? Contact our support desk at support@reliable.trust",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Blocked Users List
            item {
                Text(text = "Blocked Users (${blockedUsers.size})", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldAccent))
            }

            if (blockedUsers.isEmpty()) {
                item {
                    Text(text = "You have not blocked any users.", style = MaterialTheme.typography.bodySmall, color = SlateGray)
                }
            } else {
                items(blockedUsers) { block ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = OceanSlate)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Block, contentDescription = null, tint = AlertRed)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = block.blockedName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Text(text = block.blockedPhone, style = MaterialTheme.typography.bodySmall, color = SlateGray)
                            }
                            TextButton(onClick = { onUnblockUser(block.blockedUserId) }) {
                                Text("Unblock", color = GoldAccent)
                            }
                        }
                    }
                }
            }

            // Actions: Logout & Delete Account
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_logout_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariantDark, contentColor = MaterialTheme.colorScheme.onBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign Out", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }
            }

            item {
                OutlinedButton(
                    onClick = onNavigateDeleteAccount,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_delete_account_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(AlertRed)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = AlertRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete Account Permanently", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
