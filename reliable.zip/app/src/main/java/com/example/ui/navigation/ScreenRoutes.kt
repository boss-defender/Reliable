package com.example.ui.navigation

object ScreenRoutes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val REGISTER = "register"
    const val LOGIN = "login"
    const val HOME = "home"
    const val PARTNER_LINK = "partner_link"
    const val ENTER_CODE = "enter_code"
    const val STATUS_CHECK = "status_check"
    const val SETTINGS = "settings"
    const val REPORT_BLOCK = "report_block"
    const val DELETE_ACCOUNT = "delete_account"
    const val KYC = "kyc"
    const val AUDIT_LOG = "audit_log"
}
