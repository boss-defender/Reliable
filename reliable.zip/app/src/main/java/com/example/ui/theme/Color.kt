package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Utility / Minimal Design Tokens
val UtilityBackground = Color(0xFFFBFDF8)
val UtilityDarkText = Color(0xFF00210B)
val PrimaryForestGreen = Color(0xFF006D32)
val SoftMintContainer = Color(0xFFE9F5E9)
val MintPill = Color(0xFFD0E8D7)
val CardWhite = Color(0xFFFFFFFF)
val CardLightVariant = Color(0xFFF2F5F1)
val SubtleBorder = Color(0xFFD0E8D7)
val SecondaryTextGray = Color(0xFF414941)
val LabelTextGray = Color(0xFF717971)

// Color Mappings for UI Consistency across Clean Utility / Minimal theme
val DeepNavy = UtilityBackground
val OceanSlate = CardWhite
val MidnightCard = SoftMintContainer
val SurfaceVariantDark = MintPill

val GoldAccent = PrimaryForestGreen
val TealTrust = PrimaryForestGreen
val VerifiedGreen = PrimaryForestGreen
val PendingAmber = Color(0xFFD97706)
val AlertRed = Color(0xFFBA1A1A)

val OffWhite = UtilityDarkText
val SlateGray = SecondaryTextGray
val DarkText = UtilityDarkText
val LightSurface = UtilityBackground
val LightCard = CardWhite


