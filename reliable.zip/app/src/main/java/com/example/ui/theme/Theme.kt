package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val ReliableCleanColorScheme = lightColorScheme(
  primary = PrimaryForestGreen,
  onPrimary = Color.White,
  primaryContainer = SoftMintContainer,
  onPrimaryContainer = PrimaryForestGreen,
  secondary = MintPill,
  onSecondary = UtilityDarkText,
  tertiary = PrimaryForestGreen,
  background = UtilityBackground,
  onBackground = UtilityDarkText,
  surface = CardWhite,
  onSurface = UtilityDarkText,
  surfaceVariant = CardLightVariant,
  onSurfaceVariant = SecondaryTextGray,
  outline = SubtleBorder,
  error = AlertRed,
  onError = Color.White
)

@Composable
fun ReliableTheme(
  darkTheme: Boolean = false, // Clean Utility / Minimal light theme default
  dynamicColor: Boolean = false, // Pure brand palette
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    else -> ReliableCleanColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit
) {
  ReliableTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

