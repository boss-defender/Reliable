package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AuditLogEntity
import com.example.data.local.BlockEntity
import com.example.data.local.PartnerInviteEntity
import com.example.data.local.UserEntity
import com.example.data.repository.ReliableRepository
import com.example.data.repository.Resource
import com.example.util.SessionManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReliableRepository
    val sessionManager: SessionManager = SessionManager(application)

    private val _currentUserId = MutableStateFlow<String?>(sessionManager.getUserId())
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _uiMessage = MutableSharedFlow<String>()
    val uiMessage: SharedFlow<String> = _uiMessage.asSharedFlow()

    private val _errorMessage = MutableSharedFlow<String>()
    val errorMessage: SharedFlow<String> = _errorMessage.asSharedFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ReliableRepository(db.reliableDao())
    }

    private val _hasConnectionError = MutableStateFlow(false)
    val hasConnectionError: StateFlow<Boolean> = _hasConnectionError.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentUser: StateFlow<UserEntity?> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) {
            repository.getUserFlow(userId).onEach { user ->
                if (user != null) {
                    sessionManager.saveCachedRelationshipStatus(user.currentStatus, user.partnerDisplayName)
                }
            }
        } else {
            flowOf(null)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeInvite: StateFlow<PartnerInviteEntity?> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) {
            repository.getActiveInviteFlow(userId)
        } else {
            flowOf(null)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val blockedUsers: StateFlow<List<BlockEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) {
            repository.getBlockedUsersFlow(userId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val auditLogs: StateFlow<List<AuditLogEntity>> = _currentUserId.flatMapLatest { userId ->
        if (userId != null) {
            repository.getAuditLogsFlow(userId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun register(phone: String, pass: String, confirmPass: String, name: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.register(phone, pass, confirmPass, name)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    val user = res.data
                    sessionManager.saveSession(user.id, "TOKEN_${user.id}")
                    _currentUserId.value = user.id
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun login(phone: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.login(phone, pass)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    val user = res.data
                    sessionManager.saveSession(user.id, "TOKEN_${user.id}")
                    _currentUserId.value = user.id
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        sessionManager.clearSession()
        _currentUserId.value = null
        onLoggedOut()
    }

    fun generateInviteCode() {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.generatePartnerInviteCode(userId)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun verifyAndLinkCode(code: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.verifyAndLinkPartnerCode(userId, code)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    fun clearConnectionError() {
        _hasConnectionError.value = false
    }

    fun refreshData() {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isRefreshing.value = true
            _hasConnectionError.value = false
            when (val res = repository.refreshUserData(userId)) {
                is Resource.Success -> {
                    _isRefreshing.value = false
                    _hasConnectionError.value = false
                }
                is Resource.Error -> {
                    _isRefreshing.value = false
                    _hasConnectionError.value = true
                    _errorMessage.emit(res.message)
                }
                else -> { _isRefreshing.value = false }
            }
        }
    }

    fun requestUnlinkPartner(onSuccess: () -> Unit = {}) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.requestUnlinkPartner(userId)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun confirmUnlinkPartner(onSuccess: () -> Unit = {}) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.confirmUnlinkPartner(userId)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun cancelUnlinkRequest() {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.cancelUnlinkRequest(userId)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun unlinkPartner(onSuccess: () -> Unit = {}) {
        confirmUnlinkPartner(onSuccess)
    }

    fun reportUser(reportedUserId: String, reportedName: String, reason: String, details: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.reportUser(userId, reportedUserId, reportedName, reason, details)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun blockUser(blockedUserId: String, blockedName: String, blockedPhone: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.blockUser(userId, blockedUserId, blockedName, blockedPhone)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun unblockUser(blockedUserId: String) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            when (val res = repository.unblockUser(userId, blockedUserId)) {
                is Resource.Success -> { _uiMessage.emit(res.message) }
                is Resource.Error -> { _errorMessage.emit(res.message) }
                else -> {}
            }
        }
    }

    fun changePassword(currentPass: String, newPass: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.changePassword(userId, currentPass, newPass)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }

    fun deleteAccount(confirmPass: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            when (val res = repository.deleteAccount(userId, confirmPass)) {
                is Resource.Success -> {
                    _isLoading.value = false
                    sessionManager.clearSession()
                    _currentUserId.value = null
                    _uiMessage.emit(res.message)
                    onSuccess()
                }
                is Resource.Error -> {
                    _isLoading.value = false
                    _errorMessage.emit(res.message)
                }
                else -> { _isLoading.value = false }
            }
        }
    }
}
